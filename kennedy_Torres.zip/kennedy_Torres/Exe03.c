#include <stdio.h>

int main(){

    float largura, altura, area=0, consumo=0, latas=0;
    

    printf("iremos calcular a quantidade de tintas necessaria para pintar a parede\n\n");
    printf("Defina as medidas, em metros, da largura da parede:\n");
    scanf("%f",&largura);
    printf("Defina as medidas, em metros, da altura da parede:\n");
    scanf("%f",&altura);
    
    area = largura*altura;
    consumo = 300*area; //1m² = 300ml 
    latas = consumo/2000; // capacidade de 1 lata = 2000ml 

    printf("\nSerao necessarias %.1f latas de tinta para pintar toda a parede", latas);
    return 0;
}